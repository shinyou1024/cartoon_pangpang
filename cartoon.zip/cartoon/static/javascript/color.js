
  var black = function(){
   this.currentColor = '#000000';
  }
  var red = function(){
   this.currentColor = '#ff0000';
  }
  var green = function(){
   this.currentColor = '#00ff00';
  }
  var blue = function(){
   this.currentColor = '#0000ff';
  }
  var yellow = function(){
   this.currentColor = '#ffff00';
  }
